package com.spectra.player.data.repository

import android.content.Context
import androidx.room.*
import com.spectra.player.data.model.Track
import kotlinx.coroutines.flow.Flow

// ── DAO ──────────────────────────────────────────────────────────────────────

@Dao
interface TrackDao {
    @Query("SELECT * FROM tracks ORDER BY artist, album, trackNumber")
    fun getAllTracks(): Flow<List<Track>>

    @Query("SELECT * FROM tracks WHERE id = :id")
    suspend fun getTrackById(id: Long): Track?

    @Query("SELECT DISTINCT album FROM tracks ORDER BY album")
    fun getAlbums(): Flow<List<String>>

    @Query("SELECT DISTINCT artist FROM tracks ORDER BY artist")
    fun getArtists(): Flow<List<String>>

    @Query("SELECT * FROM tracks WHERE album = :album ORDER BY trackNumber")
    fun getTracksByAlbum(album: String): Flow<List<Track>>

    @Query("SELECT * FROM tracks WHERE artist = :artist ORDER BY album, trackNumber")
    fun getTracksByArtist(artist: String): Flow<List<Track>>

    @Query("SELECT * FROM tracks WHERE title LIKE '%' || :query || '%' OR artist LIKE '%' || :query || '%' OR album LIKE '%' || :query || '%'")
    fun searchTracks(query: String): Flow<List<Track>>

    @Upsert
    suspend fun upsertTracks(tracks: List<Track>)

    @Query("DELETE FROM tracks WHERE id NOT IN (:ids)")
    suspend fun removeDeletedTracks(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM tracks")
    suspend fun getTrackCount(): Int
}

// ── DATABASE ─────────────────────────────────────────────────────────────────

@Database(entities = [Track::class], version = 1, exportSchema = false)
abstract class SpectraDatabase : RoomDatabase() {
    abstract fun trackDao(): TrackDao

    companion object {
        @Volatile private var INSTANCE: SpectraDatabase? = null

        fun getInstance(context: Context): SpectraDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    SpectraDatabase::class.java,
                    "spectra_db"
                ).build().also { INSTANCE = it }
            }
    }
}
