package com.spectra.player.audio

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.spectra.player.data.model.Track
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

/** Thin wrapper that exposes ExoPlayer state as Kotlin Flows. */
class PlayerController(context: Context) {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val _currentTrack   = MutableStateFlow<Track?>(null)
    private val _isPlaying      = MutableStateFlow(false)
    private val _position       = MutableStateFlow(0L)
    private val _duration       = MutableStateFlow(0L)
    private val _queue          = MutableStateFlow<List<Track>>(emptyList())
    private val _currentIndex   = MutableStateFlow(0)

    val currentTrack: StateFlow<Track?> = _currentTrack.asStateFlow()
    val isPlaying:    StateFlow<Boolean> = _isPlaying.asStateFlow()
    val position:     StateFlow<Long>    = _position.asStateFlow()
    val duration:     StateFlow<Long>    = _duration.asStateFlow()
    val queue:        StateFlow<List<Track>> = _queue.asStateFlow()
    val currentIndex: StateFlow<Int>     = _currentIndex.asStateFlow()

    private var controller: MediaController? = null
    private val controllerFuture: ListenableFuture<MediaController>

    init {
        val sessionToken = SessionToken(
            context,
            ComponentName(context, PlaybackService::class.java)
        )
        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture.addListener({
            controller = controllerFuture.get()
            controller?.addListener(playerListener)
            startPositionPolling()
        }, MoreExecutors.directExecutor())
    }

    // ── Playback Listener ───────────────────────────────────────────────────

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) {
            _isPlaying.value = playing
        }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val idx = controller?.currentMediaItemIndex ?: 0
            _currentIndex.value = idx
            _currentTrack.value = _queue.value.getOrNull(idx)
            _duration.value = controller?.duration?.coerceAtLeast(0) ?: 0
        }
    }

    // ── Position polling ────────────────────────────────────────────────────

    private fun startPositionPolling() {
        scope.launch {
            while (isActive) {
                _position.value = controller?.currentPosition?.coerceAtLeast(0) ?: 0
                _duration.value = controller?.duration?.coerceAtLeast(0) ?: 0
                delay(500)
            }
        }
    }

    // ── Public API ──────────────────────────────────────────────────────────

    fun playQueue(tracks: List<Track>, startIndex: Int = 0) {
        _queue.value = tracks
        _currentIndex.value = startIndex
        _currentTrack.value = tracks.getOrNull(startIndex)

        val mediaItems = tracks.map { track ->
            MediaItem.Builder()
                .setUri(track.toMediaUri())
                .setMediaId(track.id.toString())
                .build()
        }
        controller?.apply {
            setMediaItems(mediaItems, startIndex, 0)
            prepare()
            play()
        }
    }

    fun playPause() {
        controller?.let {
            if (it.isPlaying) it.pause() else it.play()
        }
    }

    fun skipNext() {
        controller?.seekToNextMediaItem()
    }

    fun skipPrevious() {
        val ctrl = controller ?: return
        if (ctrl.currentPosition > 3000) {
            ctrl.seekTo(0)
        } else {
            ctrl.seekToPreviousMediaItem()
        }
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
    }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun setRepeatMode(mode: Int) {
        controller?.repeatMode = mode
    }

    fun release() {
        scope.cancel()
        controller?.removeListener(playerListener)
        MediaController.releaseFuture(controllerFuture)
    }
}
