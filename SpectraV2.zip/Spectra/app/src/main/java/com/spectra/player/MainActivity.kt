package com.spectra.player

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.spectra.player.ui.screens.LibraryScreen
import com.spectra.player.ui.screens.PlayerScreen
import com.spectra.player.ui.screens.SettingsScreen
import com.spectra.player.ui.theme.*

enum class AppScreen { PLAYER, LIBRARY, SETTINGS }

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.any { it }) {
            vm.refreshLibrary()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestStoragePermissions()

        setContent {
            SpectraTheme {
                SpectraApp(vm)
            }
        }
    }

    private fun requestStoragePermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        } else {
            vm.refreshLibrary()
        }
        } // end Row
    } // end Column
}

@Composable
fun SpectraApp(vm: MainViewModel) {
    var screen by remember { mutableStateOf(AppScreen.PLAYER) }
    val currentTrack by vm.currentTrack.collectAsState()
    val isPlaying    by vm.isPlaying.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // ── App Header ──────────────────────────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Background)
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "SPECTRA",
                        color = Accent,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp,
                    )
                    Text(
                        "HI-RES AUDIO LABORATORY",
                        color = TextTertiary,
                        fontSize = 7.sp,
                        letterSpacing = 1.5.sp,
                        fontFamily = FontFamily.Monospace,
                    )
                }
                // DAC status pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Accent.copy(alpha = 0.08f))
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    DacDot()
                    Text("USB DAC", color = Accent, fontSize = 8.sp,
                        letterSpacing = 0.8.sp, fontFamily = FontFamily.Monospace)
                }
            }
            HorizontalDivider(color = Border, thickness = 1.dp)

            // ── Page Content ────────────────────────────────────────────────
            Box(modifier = Modifier.weight(1f).padding(bottom = 60.dp)) {
                when (screen) {
                    AppScreen.PLAYER   -> PlayerScreen(vm)
                    AppScreen.LIBRARY  -> LibraryScreen(vm)
                    AppScreen.SETTINGS -> SettingsScreen()
                }
            }
        }

        // ── Bottom Navigation ───────────────────────────────────────────────
        BottomNav(
            current    = screen,
            onNavigate = { screen = it },
            modifier   = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
fun DacDot() {
    val infinite = rememberInfiniteTransition(label = "dac")
    val alpha by infinite.animateFloat(
        initialValue = 1f, targetValue = 0.3f,
        animationSpec = infiniteRepeatable(
            androidx.compose.animation.core.tween(1000),
            androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "dacAlpha"
    )
    Box(
        modifier = Modifier
            .size(5.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(Accent.copy(alpha = alpha))
    )
}

@Composable
fun BottomNav(current: AppScreen, onNavigate: (AppScreen) -> Unit, modifier: Modifier = Modifier) {
    val items = listOf(
        Triple(AppScreen.PLAYER,   "▶",  "PLAYER"),
        Triple(AppScreen.LIBRARY,  "⊞",  "LIBRARY"),
        Triple(AppScreen.SETTINGS, "⚙",  "SETTINGS"),
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Background.copy(alpha = 0.95f))
    ) {
        HorizontalDivider(color = Border, thickness = 1.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
        items.forEach { (screen, icon, label) ->
            val selected = screen == current
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clickable { onNavigate(screen) }
                    .padding(horizontal = 24.dp, vertical = 6.dp)
            ) {
                Text(
                    text = icon,
                    fontSize = 16.sp,
                    color = if (selected) Accent else TextTertiary,
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    text = label,
                    fontSize = 7.sp,
                    letterSpacing = 0.8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (selected) Accent else TextTertiary,
                )
            }
        }
        } // Row
    } // Column
}
