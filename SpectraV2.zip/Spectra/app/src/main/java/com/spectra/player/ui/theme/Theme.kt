package com.spectra.player.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

// ── Colour palette ──────────────────────────────────────────────────────────

val Background    = Color(0xFF080C0E)
val Surface       = Color(0xFF0D1315)
val Surface2      = Color(0xFF111A1E)
val Surface3      = Color(0xFF162028)
val Border        = Color(0xFF1E3040)
val Border2       = Color(0xFF243848)

val Accent        = Color(0xFF00E5B0)
val AccentBlue    = Color(0xFF00B5E8)
val AccentPurple  = Color(0xFF7B5EA7)
val Warning       = Color(0xFFF0A500)
val Hot           = Color(0xFFFF4D6D)

val TextPrimary   = Color(0xFFC8DDE8)
val TextSecondary = Color(0xFF6A8FA0)
val TextTertiary  = Color(0xFF3A5568)

// ── Material3 dark colour scheme ────────────────────────────────────────────

private val SpectraColorScheme = darkColorScheme(
    primary          = Accent,
    onPrimary        = Background,
    primaryContainer = Surface3,
    secondary        = AccentBlue,
    onSecondary      = Background,
    background       = Background,
    surface          = Surface,
    onSurface        = TextPrimary,
    onBackground     = TextPrimary,
    surfaceVariant   = Surface2,
    outline          = Border,
    error            = Hot,
)

@Composable
fun SpectraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SpectraColorScheme,
        content     = content
    )
}
