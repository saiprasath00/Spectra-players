package com.spectra.player

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.spectra.player.audio.PlayerController
import com.spectra.player.data.model.Track
import com.spectra.player.data.repository.MusicRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class LibraryState(
    val tracks: List<Track> = emptyList(),
    val albums: Map<String, List<Track>> = emptyMap(),
    val artists: Map<String, List<Track>> = emptyMap(),
    val isScanning: Boolean = false,
    val totalTracks: Int = 0,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val repository      = MusicRepository(app)
    val playerController = PlayerController(app)

    // ── Player state (delegated from PlayerController) ──────────────────────
    val currentTrack  = playerController.currentTrack
    val isPlaying     = playerController.isPlaying
    val position      = playerController.position
    val duration      = playerController.duration
    val queue         = playerController.queue
    val currentIndex  = playerController.currentIndex

    // ── Library state ───────────────────────────────────────────────────────
    private val _libState = MutableStateFlow(LibraryState())
    val libState: StateFlow<LibraryState> = _libState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val searchResults: StateFlow<List<Track>> = _searchQuery
        .debounce(300)
        .flatMapLatest { query ->
            if (query.isBlank()) flowOf(emptyList())
            else repository.searchTracks(query)
        }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    init {
        // Observe DB
        viewModelScope.launch {
            repository.allTracks.collect { tracks ->
                val albumMap  = tracks.groupBy { it.album }
                val artistMap = tracks.groupBy { it.artist }
                _libState.update { it.copy(
                    tracks     = tracks,
                    albums     = albumMap,
                    artists    = artistMap,
                    totalTracks = tracks.size
                )}
            }
        }
        // Auto-scan on first launch
        refreshLibrary()
    }

    fun refreshLibrary() {
        viewModelScope.launch {
            _libState.update { it.copy(isScanning = true) }
            repository.refreshLibrary()
            _libState.update { it.copy(isScanning = false) }
        }
    }

    fun playTrack(track: Track) {
        val tracks = libState.value.tracks
        val idx    = tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        playerController.playQueue(tracks, idx)
    }

    fun playAlbum(album: String, startTrack: Track? = null) {
        val tracks = libState.value.albums[album] ?: return
        val idx    = startTrack?.let { t -> tracks.indexOfFirst { it.id == t.id } } ?: 0
        playerController.playQueue(tracks, idx.coerceAtLeast(0))
    }

    fun playPause()     = playerController.playPause()
    fun skipNext()      = playerController.skipNext()
    fun skipPrevious()  = playerController.skipPrevious()
    fun seekTo(ms: Long) = playerController.seekTo(ms)

    fun setSearchQuery(q: String) { _searchQuery.value = q }

    override fun onCleared() {
        super.onCleared()
        playerController.release()
    }
}
