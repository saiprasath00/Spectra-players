package com.spectra.player.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.spectra.player.MainViewModel
import com.spectra.player.data.model.Track
import com.spectra.player.ui.components.FormatBadge
import com.spectra.player.ui.components.TrackRow
import com.spectra.player.ui.theme.*

enum class LibTab { ALBUMS, ARTISTS, TRACKS }

@Composable
fun LibraryScreen(vm: MainViewModel) {
    val libState    by vm.libState.collectAsState()
    val searchQuery by vm.searchQuery.collectAsState()
    val searchResults by vm.searchResults.collectAsState()
    var activeTab   by remember { mutableStateOf(LibTab.ALBUMS) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
    ) {
        // ── Search ──────────────────────────────────────────────────────────
        OutlinedTextField(
            value = searchQuery,
            onValueChange = vm::setSearchQuery,
            placeholder = { Text("Search tracks, artists, albums…",
                color = TextTertiary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = TextTertiary) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor   = AccentBlue,
                unfocusedBorderColor = Border,
                focusedTextColor     = TextPrimary,
                unfocusedTextColor   = TextPrimary,
                cursorColor          = Accent,
            ),
            shape = RoundedCornerShape(4.dp)
        )

        // ── Tabs ────────────────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Surface)
                .border(1.dp, Border, RoundedCornerShape(4.dp))
                .padding(3.dp),
        ) {
            LibTab.values().forEach { tab ->
                val selected = tab == activeTab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (selected) Surface3 else Color.Transparent)
                        .border(if (selected) 1.dp else 0.dp, if (selected) Border2 else Color.Transparent, RoundedCornerShape(3.dp))
                        .clickable { activeTab = tab }
                        .padding(vertical = 7.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab.name,
                        color = if (selected) Accent else TextTertiary,
                        fontSize = 8.sp,
                        letterSpacing = 1.sp,
                        fontFamily = FontFamily.Monospace,
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ── Stats row ────────────────────────────────────────────────────────
        Row(
            modifier = Modifier.padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatChip("${libState.totalTracks} TRACKS")
            StatChip("${libState.albums.size} ALBUMS")
            if (libState.isScanning) StatChip("SCANNING…", Accent)
        }

        Spacer(Modifier.height(12.dp))

        // ── Content ──────────────────────────────────────────────────────────
        if (searchQuery.isNotBlank()) {
            // Search results
            LazyColumn {
                items(searchResults, key = { it.id }) { track ->
                    TrackRow(
                        track       = track,
                        isActive    = false,
                        trackNumber = 0,
                        onClick     = { vm.playTrack(track) }
                    )
                }
            }
        } else {
            when (activeTab) {
                LibTab.ALBUMS -> AlbumsGrid(vm)
                LibTab.ARTISTS -> ArtistsList(vm)
                LibTab.TRACKS -> TracksList(vm)
            }
        }
    }
}

@Composable
fun AlbumsGrid(vm: MainViewModel) {
    val libState by vm.libState.collectAsState()
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        libState.albums.forEach { (album, tracks) ->
            item(key = album) {
                AlbumCard(
                    albumName = album,
                    artist    = tracks.firstOrNull()?.artist ?: "",
                    artUri    = tracks.firstOrNull()?.albumArtUri,
                    trackCount = tracks.size,
                    format    = tracks.firstOrNull(),
                    onClick   = { vm.playAlbum(album) }
                )
            }
        }
    }
}

@Composable
fun AlbumCard(
    albumName:  String,
    artist:     String,
    artUri:     String?,
    trackCount: Int,
    format:     Track?,
    onClick:    () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Surface)
            .border(1.dp, Border, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(3.dp))
                .background(Surface3)
        ) {
            AsyncImage(
                model = artUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(albumName, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(artist, color = TextSecondary, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(5.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            format?.let { FormatBadge(it) }
            Text("$trackCount tracks", color = TextTertiary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun ArtistsList(vm: MainViewModel) {
    val libState by vm.libState.collectAsState()
    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp)) {
        libState.artists.forEach { (artist, tracks) ->
            item(key = artist) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.playAlbum(tracks.first().album) }
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(artist, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("${tracks.size} tracks · ${tracks.map { it.album }.toSet().size} albums",
                            color = TextSecondary, fontSize = 10.sp)
                    }
                    Text("▶", color = TextTertiary, fontSize = 12.sp)
                }
                HorizontalDivider(color = Border, thickness = 0.5.dp)
            }
        }
    }
}

@Composable
fun TracksList(vm: MainViewModel) {
    val libState by vm.libState.collectAsState()
    LazyColumn {
        itemsIndexed(libState.tracks, key = { _, t -> t.id }) { idx, track ->
            TrackRow(
                track       = track,
                isActive    = false,
                trackNumber = idx + 1,
                onClick     = { vm.playTrack(track) }
            )
        }
    }
}

@Composable
fun StatChip(text: String, color: Color = TextTertiary) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Surface)
            .border(1.dp, Border, RoundedCornerShape(20.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text, color = color, fontSize = 7.sp, letterSpacing = 0.8.sp,
            fontFamily = FontFamily.Monospace)
    }
}
