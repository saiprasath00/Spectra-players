package com.spectra.player.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.spectra.player.ui.theme.*

data class SettingItem(
    val label: String,
    val sub:   String,
    val type:  SettingType,
    val value: String = "",
    val defaultOn: Boolean = false,
)

sealed class SettingType {
    object Toggle : SettingType()
    data class Value(val display: String) : SettingType()
    object Arrow  : SettingType()
}

@Composable
fun SettingsScreen() {
    val groups = listOf(
        "PLAYBACK ENGINE" to listOf(
            SettingItem("Bit-Perfect Mode", "Bypass system mixer entirely", SettingType.Toggle, defaultOn = true),
            SettingItem("USB Exclusive Mode", "Direct hardware DAC access", SettingType.Toggle, defaultOn = true),
            SettingItem("Gapless Playback", "Seamless track transitions", SettingType.Toggle, defaultOn = true),
            SettingItem("Buffer Size", "Lower = less latency, more CPU", SettingType.Value("512 samples")),
        ),
        "AUDIO PROCESSING" to listOf(
            SettingItem("ReplayGain", "Volume normalization", SettingType.Toggle, defaultOn = false),
            SettingItem("Crossfeed", "Speaker simulation on headphones", SettingType.Toggle, defaultOn = false),
            SettingItem("Dither", "Noise shaping on bit reduction", SettingType.Toggle, defaultOn = true),
            SettingItem("Sample Rate Output", "Target rate for conversion", SettingType.Value("Native")),
        ),
        "OUTPUT DEVICE" to listOf(
            SettingItem("Audio Output", "Current playback device", SettingType.Value("ES9038PRO DAC")),
            SettingItem("Hardware Volume", "DAC attenuation control", SettingType.Toggle, defaultOn = true),
            SettingItem("MQA Passthrough", "Send undecoded MQA to DAC", SettingType.Toggle, defaultOn = false),
        ),
        "LIBRARY" to listOf(
            SettingItem("Scan Music Library", "Refresh from device storage", SettingType.Arrow),
            SettingItem("Show Hi-Res Only", "Filter to lossless formats", SettingType.Toggle, defaultOn = false),
        ),
        "ABOUT" to listOf(
            SettingItem("Version", "Audio engine build", SettingType.Value("2.4.1")),
            SettingItem("ExoPlayer", "Media3 playback engine", SettingType.Value("1.4.0")),
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(Modifier.height(4.dp))
        groups.forEach { (groupName, items) ->
            SettingsGroup(groupName, items)
            Spacer(Modifier.height(20.dp))
        }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
fun SettingsGroup(title: String, items: List<SettingItem>) {
    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        Text(title, color = TextTertiary, fontSize = 7.sp, letterSpacing = 1.5.sp,
            fontFamily = FontFamily.Monospace, modifier = Modifier.padding(start = 2.dp, bottom = 8.dp))

        items.forEachIndexed { idx, item ->
            val radius = when {
                items.size == 1 -> RoundedCornerShape(4.dp)
                idx == 0        -> RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)
                idx == items.lastIndex -> RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp)
                else            -> RoundedCornerShape(0.dp)
            }
            SettingsRow(item, radius)
            if (idx < items.lastIndex) {
                HorizontalDivider(color = Border, thickness = 0.5.dp,
                    modifier = Modifier.padding(start = 16.dp))
            }
        }
    }
}

@Composable
fun SettingsRow(item: SettingItem, shape: RoundedCornerShape) {
    var toggled by remember { mutableStateOf(item.defaultOn) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Surface)
            .clickable {
                if (item.type is SettingType.Toggle) toggled = !toggled
            }
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(item.label, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(item.sub, color = TextTertiary, fontSize = 9.sp, letterSpacing = 0.3.sp)
        }
        Spacer(Modifier.width(12.dp))
        when (item.type) {
            is SettingType.Toggle -> {
                Switch(
                    checked = toggled,
                    onCheckedChange = { toggled = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor  = Background,
                        checkedTrackColor  = Accent,
                        uncheckedThumbColor = TextTertiary,
                        uncheckedTrackColor = Surface3,
                        uncheckedBorderColor = Border2,
                    )
                )
            }
            is SettingType.Value -> {
                Text(item.type.display, color = AccentBlue, fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace)
            }
            is SettingType.Arrow -> {
                Text("›", color = TextSecondary, fontSize = 18.sp)
            }
        }
    }
}
