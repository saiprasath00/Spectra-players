package com.spectra.player.data.repository

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.spectra.player.data.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaScanner(private val context: Context) {

    private val supportedFormats = setOf(
        "audio/flac", "audio/x-flac",
        "audio/wav", "audio/x-wav",
        "audio/aiff", "audio/x-aiff",
        "audio/alac",
        "audio/mp4",       // includes ALAC
        "audio/mpeg",      // MP3
        "audio/aac",
        "audio/ogg",
        "audio/dsd",       // DSD (device dependent)
    )

    suspend fun scanDevice(): List<Track> = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<Track>()
        val contentResolver: ContentResolver = context.contentResolver

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.BITRATE,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DATA,
        )

        val sortOrder = "${MediaStore.Audio.Media.ARTIST} ASC, " +
                        "${MediaStore.Audio.Media.ALBUM} ASC, " +
                        "${MediaStore.Audio.Media.TRACK} ASC"

        contentResolver.query(collection, projection, null, null, sortOrder)?.use { cursor ->
            val idCol      = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol   = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol  = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol   = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val bitrateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.BITRATE)
            val sizeCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val trackCol   = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val yearCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val mimeCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)

            while (cursor.moveToNext()) {
                val id       = cursor.getLong(idCol)
                val mimeType = cursor.getString(mimeCol) ?: continue
                val duration = cursor.getLong(durCol)
                if (duration < 1000) continue // skip noise / ringtones

                val contentUri = ContentUris.withAppendedId(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id
                )
                val albumId   = cursor.getLong(albumIdCol)
                val albumArt  = getAlbumArtUri(albumId)

                // Extract sample rate & bit depth via MediaMetadataRetriever
                val (sampleRate, bitDepth, format) = extractAudioMetadata(contentUri, mimeType)

                tracks.add(
                    Track(
                        id          = id,
                        uri         = contentUri.toString(),
                        title       = cursor.getString(titleCol) ?: "Unknown Title",
                        artist      = cursor.getString(artistCol) ?: "Unknown Artist",
                        album       = cursor.getString(albumCol) ?: "Unknown Album",
                        albumArtUri = albumArt,
                        duration    = duration,
                        sampleRate  = sampleRate,
                        bitDepth    = bitDepth,
                        bitrate     = cursor.getInt(bitrateCol) / 1000,
                        format      = format,
                        fileSize    = cursor.getLong(sizeCol),
                        trackNumber = cursor.getInt(trackCol) % 1000,
                        year        = cursor.getInt(yearCol),
                        genre       = "",
                    )
                )
            }
        }

        tracks
    }

    private fun getAlbumArtUri(albumId: Long): String? {
        val albumArtUri = Uri.parse("content://media/external/audio/albumart")
        return ContentUris.withAppendedId(albumArtUri, albumId).toString()
    }

    private fun extractAudioMetadata(uri: Uri, mimeType: String): Triple<Int, Int, String> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val sampleRate = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE)
                ?.toIntOrNull() ?: 44100
            val bitDepth = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITS_PER_SAMPLE)
                ?.toIntOrNull() ?: 16
            val format = mimeTypeToFormat(mimeType)
            Triple(sampleRate, bitDepth, format)
        } catch (e: Exception) {
            Triple(44100, 16, mimeTypeToFormat(mimeType))
        } finally {
            retriever.release()
        }
    }

    private fun mimeTypeToFormat(mimeType: String): String = when {
        mimeType.contains("flac") -> "FLAC"
        mimeType.contains("wav")  -> "WAV"
        mimeType.contains("aiff") -> "AIFF"
        mimeType.contains("alac") -> "ALAC"
        mimeType.contains("mpeg") || mimeType.contains("mp3") -> "MP3"
        mimeType.contains("aac") || mimeType.contains("mp4") -> "AAC"
        mimeType.contains("ogg") -> "OGG"
        mimeType.contains("dsd") -> "DSD"
        else -> "AUDIO"
    }
}
