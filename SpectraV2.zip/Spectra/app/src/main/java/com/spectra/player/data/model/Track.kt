package com.spectra.player.data.model

import android.net.Uri
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class Track(
    @PrimaryKey val id: Long,
    val uri: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumArtUri: String?,
    val duration: Long,          // milliseconds
    val sampleRate: Int,         // Hz e.g. 96000
    val bitDepth: Int,           // e.g. 24
    val bitrate: Int,            // kbps
    val format: String,          // FLAC, WAV, ALAC, MP3, etc.
    val fileSize: Long,          // bytes
    val trackNumber: Int,
    val year: Int,
    val genre: String,
    val addedAt: Long = System.currentTimeMillis()
) {
    fun toMediaUri(): Uri = Uri.parse(uri)

    val isHiRes: Boolean
        get() = sampleRate > 44100 || bitDepth > 16

    val isLossless: Boolean
        get() = format in listOf("FLAC", "WAV", "AIFF", "ALAC")

    val formatBadge: String
        get() = when {
            format == "DSD" -> "DSD"
            isLossless && isHiRes -> "$format ${bitDepth}/${sampleRate / 1000}k"
            isLossless -> "$format ${bitDepth}/44.1k"
            else -> format
        }

    val durationFormatted: String
        get() {
            val totalSec = duration / 1000
            val min = totalSec / 60
            val sec = totalSec % 60
            return "$min:${sec.toString().padStart(2, '0')}"
        }
}
