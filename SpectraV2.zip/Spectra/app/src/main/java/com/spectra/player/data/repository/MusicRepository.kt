package com.spectra.player.data.repository

import android.content.Context
import com.spectra.player.data.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class MusicRepository(context: Context) {

    private val db      = SpectraDatabase.getInstance(context)
    private val dao     = db.trackDao()
    private val scanner = MediaScanner(context)

    val allTracks: Flow<List<Track>> = dao.getAllTracks()
    val albums:    Flow<List<String>> = dao.getAlbums()
    val artists:   Flow<List<String>> = dao.getArtists()

    fun getTracksByAlbum(album: String)   = dao.getTracksByAlbum(album)
    fun getTracksByArtist(artist: String) = dao.getTracksByArtist(artist)
    fun searchTracks(query: String)       = dao.searchTracks(query)

    /** Scans device storage and syncs the local DB. */
    suspend fun refreshLibrary(): Int = withContext(Dispatchers.IO) {
        val scanned = scanner.scanDevice()
        dao.upsertTracks(scanned)
        dao.removeDeletedTracks(scanned.map { it.id })
        scanned.size
    }

    suspend fun getTrackCount() = dao.getTrackCount()
}
