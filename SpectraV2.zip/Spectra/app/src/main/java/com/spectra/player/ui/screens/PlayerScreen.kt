package com.spectra.player.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.spectra.player.MainViewModel
import com.spectra.player.data.model.Track
import com.spectra.player.ui.components.FormatBadge
import com.spectra.player.ui.components.SectionLabel
import com.spectra.player.ui.components.TrackRow
import com.spectra.player.ui.theme.*

@Composable
fun PlayerScreen(vm: MainViewModel) {
    val currentTrack by vm.currentTrack.collectAsState()
    val isPlaying    by vm.isPlaying.collectAsState()
    val position     by vm.position.collectAsState()
    val duration     by vm.duration.collectAsState()
    val queue        by vm.queue.collectAsState()
    val queueIndex   by vm.currentIndex.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(Background)
    ) {
        if (currentTrack == null) {
            EmptyPlayerPlaceholder()
        } else {
            currentTrack?.let { track ->
                AlbumArtSection(track = track, isPlaying = isPlaying)

                Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                    Spacer(Modifier.height(20.dp))
                    TrackInfoSection(track)
                    Spacer(Modifier.height(16.dp))
                    ProgressSection(position, duration, onSeek = vm::seekTo)
                    Spacer(Modifier.height(16.dp))
                    ControlsSection(isPlaying, vm)
                    Spacer(Modifier.height(16.dp))
                }

                DacDashboard(track)
                Spacer(Modifier.height(12.dp))
                SignalMetersSection()
                Spacer(Modifier.height(12.dp))

                // Up next queue
                if (queue.isNotEmpty()) {
                    Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                        SectionLabel(title = "UP NEXT", badge = "${queue.size} TRACKS")
                        Spacer(Modifier.height(10.dp))
                    }
                    queue.forEachIndexed { idx, t ->
                        TrackRow(
                            track       = t,
                            isActive    = idx == queueIndex,
                            trackNumber = idx + 1,
                            onClick     = { vm.playerController.playQueue(queue, idx) }
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun EmptyPlayerPlaceholder() {
    Box(
        modifier = Modifier.fillMaxWidth().height(300.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("◈", fontSize = 48.sp, color = TextTertiary)
            Spacer(Modifier.height(16.dp))
            Text(
                "No track playing",
                color = TextSecondary,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                "Browse your library to begin",
                color = TextTertiary,
                fontSize = 10.sp,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun AlbumArtSection(track: Track, isPlaying: Boolean) {
    val rotation by rememberInfiniteTransition(label = "vinyl").animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .background(Surface)
    ) {
        // Album art
        AsyncImage(
            model = track.albumArtUri,
            contentDescription = "Album art",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Dark scrim at bottom
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Background.copy(alpha = 0.95f))
                    )
                )
        )

        // Animated vinyl disc when no art
        if (track.albumArtUri == null) {
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .align(Alignment.Center)
                    .rotate(if (isPlaying) rotation else 0f)
                    .clip(CircleShape)
                    .background(Surface2)
                    .border(1.dp, Border, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(Background)
                        .border(1.dp, Border2, CircleShape)
                )
            }
        }

        // Format badge top-right
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Background.copy(alpha = 0.85f))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Column {
                Text(track.format, color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace)
                Text("${track.bitDepth}BIT / ${track.sampleRate / 1000}kHz",
                    color = TextSecondary, fontSize = 8.sp, letterSpacing = 0.5.sp,
                    fontFamily = FontFamily.Monospace)
            }
        }

        // Bit-perfect badge bottom-left
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(12.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Background.copy(alpha = 0.85f))
                .border(1.dp, Accent.copy(alpha = 0.3f), RoundedCornerShape(3.dp))
                .padding(horizontal = 9.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Box(Modifier.size(4.dp).clip(CircleShape).background(Accent))
            Text("BIT-PERFECT", color = Accent, fontSize = 8.sp, letterSpacing = 0.8.sp,
                fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun TrackInfoSection(track: Track) {
    Text(
        text = track.title,
        color = TextPrimary,
        fontSize = 22.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
    )
    Spacer(Modifier.height(4.dp))
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(track.artist, color = TextSecondary, fontSize = 12.sp)
        Text("·", color = TextTertiary, fontSize = 12.sp)
        Text(track.album, color = AccentBlue, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun ProgressSection(position: Long, duration: Long, onSeek: (Long) -> Unit) {
    val progress = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f

    Column {
        // Slider
        Slider(
            value = progress,
            onValueChange = { onSeek((it * duration).toLong()) },
            modifier = Modifier.fillMaxWidth().height(20.dp),
            colors = SliderDefaults.colors(
                thumbColor = Accent,
                activeTrackColor = Accent,
                inactiveTrackColor = Surface3
            )
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatMs(position), color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text(formatMs(duration), color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun ControlsSection(isPlaying: Boolean, vm: MainViewModel) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        ControlButton(icon = Icons.Default.Shuffle, onClick = { vm.playerController.toggleShuffle() })
        Spacer(Modifier.width(12.dp))
        ControlButton(icon = Icons.Default.SkipPrevious, size = 32.dp, onClick = vm::skipPrevious)
        Spacer(Modifier.width(16.dp))

        // Play/Pause FAB
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(AccentBlue, Accent)))
                .clickable { vm.playPause() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = Background,
                modifier = Modifier.size(28.dp)
            )
        }

        Spacer(Modifier.width(16.dp))
        ControlButton(icon = Icons.Default.SkipNext, size = 32.dp, onClick = vm::skipNext)
        Spacer(Modifier.width(12.dp))
        ControlButton(icon = Icons.Default.Repeat, onClick = {})
    }
}

@Composable
fun ControlButton(icon: ImageVector, size: androidx.compose.ui.unit.Dp = 24.dp, onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(imageVector = icon, contentDescription = null, tint = TextSecondary,
            modifier = Modifier.size(size))
    }
}

@Composable
fun DacDashboard(track: Track) {
    Column(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Surface)
            .border(1.dp, Border, RoundedCornerShape(4.dp))
            .padding(14.dp)
    ) {
        SectionLabel(title = "DAC INTERFACE", badge = "ES9038PRO · USB")
        Spacer(Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            DacStat("${track.sampleRate / 1000}k", "SAMPLE RATE", Modifier.weight(1f))
            Box(Modifier.width(1.dp).height(40.dp).background(Border))
            DacStat("${track.bitDepth}", "BIT DEPTH", Modifier.weight(1f))
            Box(Modifier.width(1.dp).height(40.dp).background(Border))
            DacStat(track.format, "FORMAT", Modifier.weight(1f))
        }

        Spacer(Modifier.height(12.dp))
        HorizontalDivider(color = Border, thickness = 1.dp)
        Spacer(Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            DacStatusItem("BIT-PERFECT ON", true)
            DacStatusItem("USB EXCL. MODE", true)
            DacStatusItem("MQA PASSTHROUGH", false)
        }
    }
}

@Composable
fun DacStat(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Accent, fontSize = 18.sp, fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace)
        Spacer(Modifier.height(3.dp))
        Text(label, color = TextTertiary, fontSize = 7.sp, letterSpacing = 0.8.sp,
            textAlign = TextAlign.Center)
    }
}

@Composable
fun DacStatusItem(label: String, on: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            Modifier.size(4.dp).clip(CircleShape)
                .background(if (on) Accent else Warning)
        )
        Text(label, color = TextSecondary, fontSize = 7.sp, letterSpacing = 0.5.sp,
            fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun SignalMetersSection() {
    // Animated VU meters
    val infiniteTransition = rememberInfiniteTransition(label = "meters")
    val meterL by infiniteTransition.animateFloat(
        initialValue = 0.65f, targetValue = 0.88f,
        animationSpec = infiniteRepeatable(tween(300, easing = LinearEasing), RepeatMode.Reverse),
        label = "mL"
    )
    val meterR by infiniteTransition.animateFloat(
        initialValue = 0.55f, targetValue = 0.78f,
        animationSpec = infiniteRepeatable(tween(400, easing = LinearEasing), RepeatMode.Reverse),
        label = "mR"
    )

    Row(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        MeterCard("CHANNEL L/R", meterL, meterR, Modifier.weight(1f))
        MeterCard("DYN RANGE", 0.82f, 0.45f, Modifier.weight(1f), isRange = true)
    }
}

@Composable
fun MeterCard(
    title: String,
    valA: Float,
    valB: Float,
    modifier: Modifier = Modifier,
    isRange: Boolean = false
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Surface)
            .border(1.dp, Border, RoundedCornerShape(4.dp))
            .padding(12.dp)
    ) {
        Text(title, color = TextTertiary, fontSize = 7.sp, letterSpacing = 1.sp,
            fontFamily = FontFamily.Monospace)
        Spacer(Modifier.height(8.dp))

        MeterBar(valA, if (isRange) Brush.horizontalGradient(listOf(AccentPurple, AccentBlue)) else
            Brush.horizontalGradient(listOf(AccentBlue, Accent)))
        Spacer(Modifier.height(4.dp))
        MeterBar(valB, if (isRange) Brush.horizontalGradient(listOf(Warning, Hot)) else
            Brush.horizontalGradient(listOf(AccentBlue, Accent)))

        Spacer(Modifier.height(6.dp))
        if (isRange) {
            Text("DR14  -9 LUFS", color = AccentBlue, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold)
        } else {
            val dbL = (-20 * kotlin.math.log10(1.0 / valA.coerceIn(0.01f, 1f))).toInt()
            val dbR = (-20 * kotlin.math.log10(1.0 / valB.coerceIn(0.01f, 1f))).toInt()
            Text("${dbL}dBFS  ${dbR}dBFS", color = TextPrimary, fontSize = 11.sp,
                fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MeterBar(value: Float, brush: Brush) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(5.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(Surface3)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(value.coerceIn(0f, 1f))
                .fillMaxHeight()
                .clip(RoundedCornerShape(2.dp))
                .background(brush)
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────

fun formatMs(ms: Long): String {
    if (ms <= 0) return "0:00"
    val totalSec = ms / 1000
    val min = totalSec / 60
    val sec = totalSec % 60
    return "$min:${sec.toString().padStart(2, '0')}"
}
